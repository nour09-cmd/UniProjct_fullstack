export const PORT = 4545;
export const DB_URIMONGODB = "mongodb://localhost:27017/";
// export const DB_URIMONGODB = "mongodb://uniprojct_fullstack-mongo-1:27017/";
export const DB_URIPOSTGRESQL = "postgresql://admin:test@localhost:5432/barber";
// export const DB_URIPOSTGRESQL =
//   "postgresql://postgres:postgres@uniprojct_fullstack-postgres-1:5432/postgres";

export const SECRET_KEY = "tRuBEf1A0l8Heth3qAgO";

import mongoose from "mongoose";
import { DB_URIMONGODB } from "./conifg";

export class DatabaseConnection {
  private dbUri: string;

  constructor() {
    this.dbUri = DB_URIMONGODB || "";
    if (!this.dbUri) {
      console.error("Database URI not found in environment variables");
      process.exit(1);
    }
  }

  public async connect(): Promise<void> {
    try {
      const conn = await mongoose.connect(this.dbUri);

      console.log(`Database Connected: ${conn.connection.host}`);
    } catch (err) {
      console.error(`Database Error: ${(err as Error).message}`);
      process.exit(1);
    }
  }
  public async disconnect(): Promise<void> {
    try {
      await mongoose.disconnect();
      console.log(`Database disconnect`);
    } catch (err) {
      console.error(`Database Error: ${(err as Error).message}`);
      process.exit(1);
    }
  }
}

export default DatabaseConnection;

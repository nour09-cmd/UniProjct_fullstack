import { Component } from '@angular/core';

@Component({
  selector: 'app-opening-hours',
  standalone: true,
  imports: [],
  templateUrl: './opening-hours.component.html',
  styleUrl: './opening-hours.component.css'
})
export class OpeningHoursComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-mobile',
  standalone: true,
  imports: [],
  templateUrl: './navbar-mobile.component.html',
  styleUrl: './navbar-mobile.component.css'
})
export class NavbarMobileComponent {

}

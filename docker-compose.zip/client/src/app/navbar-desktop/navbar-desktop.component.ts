import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-desktop',
  standalone: true,
  imports: [],
  templateUrl: './navbar-desktop.component.html',
  styleUrl: './navbar-desktop.component.css'
})
export class NavbarDesktopComponent {

}

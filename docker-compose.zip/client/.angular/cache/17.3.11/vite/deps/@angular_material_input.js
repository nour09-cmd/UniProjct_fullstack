import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-ZW3XBQKW.js";
import "./chunk-MYSOZWTB.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-6NDVEGZA.js";
import "./chunk-IXOBJK4V.js";
import "./chunk-W7R5JJMG.js";
import "./chunk-M7GQHXKL.js";
import "./chunk-6IG72ESI.js";
import "./chunk-KNR237W5.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map

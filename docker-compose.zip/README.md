# starting

## `git clone https://github.com/nour022/UniProjct_fullstack.git`

# creat in server folder an .env

## write this inside `PORT=4545 DB_URIMONGODB=mongodb://localhost:27017/barber DB_URIPOSTGRESQL=postgresql://postgres:postgres@uniprojct_fullstack-postgres-1:5432/postgres`

# to start the frond/backend ang monogodb und postgresSQL

## just run `npm start` or `docker-compose up --build`in UniProjct_fullstack

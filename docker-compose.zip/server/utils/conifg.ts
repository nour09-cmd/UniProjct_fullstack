export const PORT = 4545;
export const DB_URIMONGODB = "mongodb://localhost:27017/";
// export const DB_URIMONGODB = "mongodb://uniprojct_fullstack-mongo-1:27017/";
export const DB_URIPOSTGRESQL = "postgresql://admin:test@localhost:5432/barber";
// export const DB_URIPOSTGRESQL =
//   "postgresql://postgres:postgres@uniprojct_fullstack-postgres-1:5432/postgres";

export const SECRET_KEY = "tRuBEf1A0l8Heth3qAgO";
export const EMAIL = "gmn09000@gmail.com";
export const PASSEWD = "iunb hhgy hqln cpzm";
export const FRONDENDSUPPORT = "http://localhost:3000/contact";
export const FRONDENDLOGIN = "http://localhost:3000/Login";
export const TERMINURL = "http://localhost:3000/contact";
export const SHOPNAME = "Barber Finder";
export const SUPPORT = "http://localhost:3000/contact";

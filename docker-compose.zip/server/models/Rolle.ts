export enum Rolle {
  USER = "USER",
  BARBER = "BARBER",
  ADMIN = "ADMIN",
}
